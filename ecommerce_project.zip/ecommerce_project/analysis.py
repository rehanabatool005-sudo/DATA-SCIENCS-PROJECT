import pandas as pd

df = pd.read_csv("ecommerce_sales_dataset.csv")

print(df.head())
df["Total_Sale"] = df["Quantity"] * df["Price"]

print("Total Sales:", df["Total_Sale"].sum())
import matplotlib.pyplot as plt

df.groupby("Product")["Total_Sale"].sum().plot(kind="bar")
plt.title("Product Wise Sales")
plt.xlabel("Product")
plt.ylabel("Sales")
plt.show()
# Total sale calculate karna
df["Total_Sale"] = df["Quantity"] * df["Price"]

# Total sales print karo
total_sales = df["Total_Sale"].sum()
print("\nTotal Sales:", total_sales)

# Product-wise sales
product_sales = df.groupby("Product")["Total_Sale"].sum()
print("\nProduct-wise Sales:")
print(product_sales)

# City-wise sales
city_sales = df.groupby("City")["Total_Sale"].sum()
print("\nCity-wise Sales:")
print(city_sales)
import matplotlib.pyplot as plt

# Product-wise sales graph
product_sales.plot(kind="bar", color="skyblue")
plt.title("Product Wise Sales")
plt.xlabel("Product")
plt.ylabel("Sales")
plt.show()

# City-wise sales graph
city_sales.plot(kind="bar", color="orange")
plt.title("City Wise Sales")
plt.xlabel("City")
plt.ylabel("Sales")
plt.show()
